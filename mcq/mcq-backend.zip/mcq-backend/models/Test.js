import mongoose from "mongoose";
import QuestionSchema from "./question.js";
import ResponseSchema from "./response.js";

const TestSchema = new mongoose.Schema({
  regno: { type: String, required: true },
  date_test: { type: String, required: true },
  max_marks: { type: Number, required: true },
  score: { type: Number, default: 0 },
  completed: { type: Boolean, default: false },
  questions: { type: [QuestionSchema], default: [] },
  responses: { type: [ResponseSchema], default: [] }
});

// ✅ Export the model (not schema)
const Test = mongoose.model("Test", TestSchema);
export default Test;
