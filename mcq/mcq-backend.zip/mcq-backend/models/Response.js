import mongoose from "mongoose";

const ResponseSchema = new mongoose.Schema({
  q_index: { type: Number, required: true },
  chosen_index: { type: Number, required: true }
});

export default ResponseSchema;
