import mongoose from "mongoose";

const QuestionSchema = new mongoose.Schema({
  q_index: { type: Number, required: true },
  question: { type: String, required: true },
  options: { type: [String], required: true },
  answerIndex: { type: Number, required: true }
});

export default QuestionSchema;
