import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import dotenv from "dotenv";
import connectDB from "./db.js";
import Test from "./models/test.js";

dotenv.config();
connectDB();

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: "2mb" }));

// --- Save / Update progress ---
app.post("/api/progress", async (req, res) => {
  try {
    const { regno, date_test, max_marks, questions, responses } = req.body;
    if (!regno) return res.status(400).json({ error: "regno required" });

    let test = await Test.findOne({ regno, date_test });
    if (!test) {
      test = new Test({ regno, date_test, max_marks, questions, responses });
    } else {
      test.questions = questions;
      test.responses = responses;
    }

    await test.save();
    res.json({ ok: true, testId: test._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Submit test ---
app.post("/api/submit", async (req, res) => {
  try {
    const { regno, date_test } = req.body;
    const test = await Test.findOne({ regno, date_test });
    if (!test) return res.status(400).json({ error: "Test not found" });

    let score = 0;
    test.responses.forEach(r => {
      const q = test.questions.find(q => q.q_index === r.q_index);
      if (q && q.answerIndex === r.chosen_index) score++;
    });

    test.score = score;
    test.completed = true;
    await test.save();

    res.json({ ok: true, score });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Resume progress ---
app.get("/api/progress", async (req, res) => {
  try {
    const { regno, date_test } = req.query;
    if (!regno) return res.status(400).json({ error: "regno required" });

    const test = await Test.findOne({ regno, date_test });
    if (!test) return res.json({ found: false });

    res.json({
      found: true,
      completed: test.completed,
      score: test.score,
      max_marks: test.max_marks,
      questions: test.questions,
      responses: test.responses
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- Leaderboard ---
app.get("/api/leaderboard", async (req, res) => {
  try {
    const leaderboard = await Test.find({ completed: true })
      .sort({ score: -1, date_test: 1 })
      .select("regno date_test score questions");

    const data = leaderboard.map(t => ({
      regno: t.regno,
      date_test: t.date_test,
      score: t.score,
      total_questions: t.questions.length,
      percentage: ((t.score / t.questions.length) * 100).toFixed(2)
    }));

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
// Admin route to add questions for a test
app.post("/api/add-questions", async (req, res) => {
  try {
    const { regno, date_test, max_marks, questions } = req.body;
    let test = await Test.findOne({ regno, date_test });
    if (!test) {
      test = new Test({ regno, date_test, max_marks, questions, responses: [] });
    } else {
      test.questions = questions;
    }
    await test.save();
    res.json({ ok: true, testId: test._id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// --- Final report ---
app.get("/api/report", async (req, res) => {
  try {
    const report = await Test.find({ completed: true })
      .sort({ score: -1 })
      .select("regno score max_marks date_test");
    res.json(report);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
