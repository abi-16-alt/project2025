import React, { useEffect, useState } from "react";
import axios from "axios";
import { useLocation } from "react-router-dom";

const Result = () => {
  const { state } = useLocation();
  const regno = state?.regno || "123";
  const dateTest = state?.dateTest || "2025-09-22";

  const [result, setResult] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:4000/api/progress", { params: { regno, date_test: dateTest } })
      .then((res) => setResult(res.data))
      .catch((err) => console.error(err));
  }, []);

  if (!result) return <div>Loading result...</div>;

  return (
    <div>
      <h2>Test Result</h2>
      {result.completed ? (
        <div>
          <p>Score: {result.score} / {result.max_marks}</p>
          <p>Total Questions: {result.questions.length}</p>
        </div>
      ) : (
        <p>Test is not yet submitted</p>
      )}
    </div>
  );
};

export default Result;
