import { useEffect, useState } from "react";
import api from "../api";

export default function Leaderboard() {
  const [leaders, setLeaders] = useState([]);

  useEffect(() => {
    async function fetchLeaderboard() {
      try {
        const res = await api.get("/api/leaderboard");
        setLeaders(res.data);
      } catch (err) {
        console.error("Error fetching leaderboard", err);
      }
    }
    fetchLeaderboard();
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h2>Leaderboard</h2>
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>Reg No</th>
            <th>Score</th>
            <th>Percentage</th>
          </tr>
        </thead>
        <tbody>
          {leaders.map((l, i) => (
            <tr key={i}>
              <td>{l.regno}</td>
              <td>{l.score}/{l.total_questions}</td>
              <td>{l.percentage}%</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
