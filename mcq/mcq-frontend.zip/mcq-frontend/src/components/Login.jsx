import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [regno, setRegno] = useState("");
  const navigate = useNavigate();
  const dateTest = new Date().toISOString().split("T")[0]; // today's date

  const handleStart = () => {
    if (!regno) return alert("Enter your roll number");
    // Navigate to MCQ test with roll number
    navigate("/test", { state: { regno, dateTest } });
  };

  return (
    <div>
      <h2>Enter Roll Number to Start Test</h2>
      <input
        type="text"
        value={regno}
        onChange={(e) => setRegno(e.target.value)}
        placeholder="Enter roll number"
      />
      <button onClick={handleStart}>Start Test</button>
    </div>
  );
};

export default Login;
