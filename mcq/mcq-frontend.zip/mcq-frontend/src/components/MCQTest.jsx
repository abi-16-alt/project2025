import { useEffect, useState } from "react";
import axios from "axios";

export default function MCQTest({ regno }) {
  const [questions, setQuestions] = useState([]);
  const [responses, setResponses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(null);

  const date_test = "2025-09-17"; // you can make this dynamic

  // Fetch test questions for this roll number
  useEffect(() => {
    async function fetchQuestions() {
      try {
        const res = await axios.get("http://localhost:4000/api/progress", {
          params: { regno, date_test },
        });

        if (res.data.found) {
          setQuestions(res.data.questions);
          setResponses(res.data.responses || []);
        } else {
          setError("No questions found for this test.");
        }
      } catch (err) {
        console.error(err);
        setError("Failed to load questions.");
      } finally {
        setLoading(false);
      }
    }

    fetchQuestions();
  }, [regno]);

  // Update chosen option for a question
  const handleOptionChange = (q_index, chosen_index) => {
    const existing = responses.find((r) => r.q_index === q_index);
    if (existing) {
      existing.chosen_index = chosen_index;
    } else {
      responses.push({ q_index, chosen_index });
    }
    setResponses([...responses]);
  };

  // Submit the test
  const handleSubmit = async () => {
    try {
      // Save progress
      await axios.post("http://localhost:4000/api/progress", {
        regno,
        date_test,
        max_marks: questions.length,
        questions,
        responses,
      });

      // Submit for scoring
      const res = await axios.post("http://localhost:4000/api/submit", {
        regno,
        date_test,
      });

      setScore(res.data.score);
      setSubmitted(true);
    } catch (err) {
      console.error(err);
      alert("Failed to submit test. Try again.");
    }
  };

  if (loading) return <p>Loading questions...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;

  if (submitted)
    return (
      <div className="p-6">
        <h1>Test Submitted ✅</h1>
        <p>
          Score: {score} / {questions.length}
        </p>
      </div>
    );

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">MCQ Test</h1>
      {questions.map((q, idx) => (
        <div key={q.q_index} className="p-4 border rounded-xl mb-4">
          <p className="font-semibold">
            {idx + 1}. {q.question}
          </p>
          <ul className="mt-2">
            {q.options.map((opt, optIdx) => {
              const checked = responses.find(
                (r) => r.q_index === q.q_index && r.chosen_index === optIdx
              );
              return (
                <li key={optIdx} className="flex items-center mb-1">
                  <input
                    type="radio"
                    name={`q-${q.q_index}`}
                    checked={!!checked}
                    onChange={() => handleOptionChange(q.q_index, optIdx)}
                    className="mr-2"
                  />
                  {opt}
                </li>
              );
            })}
          </ul>
        </div>
      ))}

      <button
        onClick={handleSubmit}
        className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        Submit Test
      </button>
    </div>
  );
}
