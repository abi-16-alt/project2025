import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import MCQTest from "./components/MCQTest";
import Result from "./components/Result";
import Leaderboard from "./components/Leaderboard";
import { useState } from "react";

export default function App() {
  const [regno, setRegno] = useState("");

  return (
    <BrowserRouter>
      <nav style={{ padding: "10px", background: "#eee" }}>
        <Link to="/">Test</Link> |{" "}
        <Link to="/result">Result</Link> |{" "}
        <Link to="/leaderboard">Leaderboard</Link>
      </nav>

      {!regno ? (
        <div style={{ padding: "20px" }}>
          <h2>Enter Your Roll Number to Start Test</h2>
          <input
            type="text"
            placeholder="Roll Number"
            value={regno}
            onChange={(e) => setRegno(e.target.value)}
            style={{ padding: "6px", fontSize: "16px", marginRight: "8px" }}
          />
          <p>After entering, navigate to <strong>Test</strong> tab to start.</p>
        </div>
      ) : (
        <Routes>
          <Route path="/" element={<MCQTest regno={regno} />} />
          <Route path="/result" element={<Result regno={regno} />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
        </Routes>
      )}
    </BrowserRouter>
  );
}
